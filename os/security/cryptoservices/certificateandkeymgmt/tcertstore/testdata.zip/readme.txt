This file contains test data for the certstore test code. 
The certificate files should be placed in a location matching that in tcertstore.cpp
